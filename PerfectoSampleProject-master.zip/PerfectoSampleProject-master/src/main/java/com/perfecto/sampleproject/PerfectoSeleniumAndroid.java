package com.perfecto.sampleproject;
import com.perfecto.sampleproject.Utils;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Platform;
import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.perfecto.reportium.client.ReportiumClient;
import com.perfecto.reportium.test.TestContext;
import com.perfecto.reportium.test.result.TestResult;
import com.perfecto.reportium.test.result.TestResultFactory;


public class PerfectoSeleniumAndroid {
	RemoteWebDriver driver;
	ReportiumClient reportiumClient;

	@Test
	public void seleniumTest() throws Exception {
		String cloudName = "adp";
		String securityToken = "eyJhbGciOiJIUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJjZGVmODI0My04YjFiLTQ1MzAtOTEzNi1iNjE4MDVlMzE1ZjgifQ.eyJqdGkiOiI4ZjE5MjE0MC1lN2M5LTQ1NjUtOTBiMC0yMTY5MjIwMGZlNTciLCJleHAiOjAsIm5iZiI6MCwiaWF0IjoxNTk3MTU0MDEyLCJpc3MiOiJodHRwczovL2F1dGgucGVyZmVjdG9tb2JpbGUuY29tL2F1dGgvcmVhbG1zL2FkcC1wZXJmZWN0b21vYmlsZS1jb20iLCJhdWQiOiJodHRwczovL2F1dGgucGVyZmVjdG9tb2JpbGUuY29tL2F1dGgvcmVhbG1zL2FkcC1wZXJmZWN0b21vYmlsZS1jb20iLCJzdWIiOiJmM2IwYjNjOS1jZWQzLTQyZmYtOWYwZi1kYzk1ZGRhMWQ0YjYiLCJ0eXAiOiJPZmZsaW5lIiwiYXpwIjoib2ZmbGluZS10b2tlbi1nZW5lcmF0b3IiLCJub25jZSI6ImJlYmY4MzUxLWE4NTYtNGUzOS04NjIxLWU3OTYyNjVmMjI3MCIsImF1dGhfdGltZSI6MCwic2Vzc2lvbl9zdGF0ZSI6IjYzZDcxMTdjLWQxZTItNGExYi1iZDQ3LTdlNDQ3ODY4NjNlNSIsInJlYWxtX2FjY2VzcyI6eyJyb2xlcyI6WyJvZmZsaW5lX2FjY2VzcyIsInVtYV9hdXRob3JpemF0aW9uIl19LCJyZXNvdXJjZV9hY2Nlc3MiOnsiYWNjb3VudCI6eyJyb2xlcyI6WyJtYW5hZ2UtYWNjb3VudCIsIm1hbmFnZS1hY2NvdW50LWxpbmtzIiwidmlldy1wcm9maWxlIl19fSwic2NvcGUiOiJvcGVuaWQgb2ZmbGluZV9hY2Nlc3MifQ.lRk5DCMUBWZmqnCEbpi0B6FuSBPqVIFwg6YenDvzx1Y";
		// Capabilities with Device ID
		DesiredCapabilities capabilities = new DesiredCapabilities("", "", Platform.ANY);
		capabilities.setCapability("securityToken", securityToken);
		capabilities.setCapability("deviceName", "RF8M8208LHL");
		try{
			System.out.println("Cloud URL - " + "https://" + cloudName + ".perfectomobile.com/nexperience/perfectomobile/wd/hub");
			driver = new RemoteWebDriver(new URL("https://" + Utils.fetchCloudName(cloudName) + ".perfectomobile.com/nexperience/perfectomobile/wd/hub"), capabilities);
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
		}catch(SessionNotCreatedException e){
			throw new RuntimeException("Driver not created with capabilities: " + capabilities.toString());
		}

		reportiumClient = Utils.setReportiumClient(driver, reportiumClient); //Creates reportiumClient
		reportiumClient.testStart("Perfecto mobile Android test", new TestContext("tag2", "tag3")); //Starts the reportium test
		reportiumClient.stepStart("Open Perfecto - Android device in perfecto"); //Starts a reportium step
		//declare the Map for script parameters
		Map<String, Object> params = new HashMap<>();
		params.put("identifier", "com.adp.run.mobile");
		driver.executeScript("mobile:application:open", params);
		System.out.println("Device started");
		reportiumClient.stepEnd();

		reportiumClient.stepStart("Close the Device");
		 //declare the Map for script parameters
		Map<String, Object> params1 = new HashMap<>();
		params1.put("identifier", "com.adp.run.mobile");
		driver.executeScript("mobile:application:close", params);
		System.out.println("App Closed");
		reportiumClient.stepEnd();
	}

	@AfterMethod
	public void afterMethod(ITestResult result) {
		//STOP TEST
		TestResult testResult = null;

		if(result.getStatus() == result.SUCCESS) {
			testResult = TestResultFactory.createSuccess();
		}
		else if (result.getStatus() == result.FAILURE) {
			testResult = TestResultFactory.createFailure(result.getThrowable());
		}
		reportiumClient.testStop(testResult);

		driver.close();
		driver.quit();
		System.out.println();
		// Retrieve the URL to the DigitalZoom Report 
		String reportURL = reportiumClient.getReportUrl();
		System.out.println(reportURL);
	}
}

