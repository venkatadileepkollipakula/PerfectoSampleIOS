package com.perfecto.sampleproject;
import com.perfecto.sampleproject.Utils;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Platform;
import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

//import com.adp.is.automation.commonmethods.util;
import com.perfecto.reportium.client.ReportiumClient;
import com.perfecto.reportium.test.TestContext;
import com.perfecto.reportium.test.result.TestResult;
import com.perfecto.reportium.test.result.TestResultFactory;


public class PerfectoSeleniumIOS {
	RemoteWebDriver driver;
	ReportiumClient reportiumClient;

	@Test
	public void seleniumTest() throws Exception {
		String cloudName = "adp";
		String securityToken = "eyJhbGciOiJIUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJjZGVmODI0My04YjFiLTQ1MzAtOTEzNi1iNjE4MDVlMzE1ZjgifQ.eyJqdGkiOiI4ZjE5MjE0MC1lN2M5LTQ1NjUtOTBiMC0yMTY5MjIwMGZlNTciLCJleHAiOjAsIm5iZiI6MCwiaWF0IjoxNTk3MTU0MDEyLCJpc3MiOiJodHRwczovL2F1dGgucGVyZmVjdG9tb2JpbGUuY29tL2F1dGgvcmVhbG1zL2FkcC1wZXJmZWN0b21vYmlsZS1jb20iLCJhdWQiOiJodHRwczovL2F1dGgucGVyZmVjdG9tb2JpbGUuY29tL2F1dGgvcmVhbG1zL2FkcC1wZXJmZWN0b21vYmlsZS1jb20iLCJzdWIiOiJmM2IwYjNjOS1jZWQzLTQyZmYtOWYwZi1kYzk1ZGRhMWQ0YjYiLCJ0eXAiOiJPZmZsaW5lIiwiYXpwIjoib2ZmbGluZS10b2tlbi1nZW5lcmF0b3IiLCJub25jZSI6ImJlYmY4MzUxLWE4NTYtNGUzOS04NjIxLWU3OTYyNjVmMjI3MCIsImF1dGhfdGltZSI6MCwic2Vzc2lvbl9zdGF0ZSI6IjYzZDcxMTdjLWQxZTItNGExYi1iZDQ3LTdlNDQ3ODY4NjNlNSIsInJlYWxtX2FjY2VzcyI6eyJyb2xlcyI6WyJvZmZsaW5lX2FjY2VzcyIsInVtYV9hdXRob3JpemF0aW9uIl19LCJyZXNvdXJjZV9hY2Nlc3MiOnsiYWNjb3VudCI6eyJyb2xlcyI6WyJtYW5hZ2UtYWNjb3VudCIsIm1hbmFnZS1hY2NvdW50LWxpbmtzIiwidmlldy1wcm9maWxlIl19fSwic2NvcGUiOiJvcGVuaWQgb2ZmbGluZV9hY2Nlc3MifQ.lRk5DCMUBWZmqnCEbpi0B6FuSBPqVIFwg6YenDvzx1Y";
		// Capabilities with Device ID
		//DesiredCapabilities capabilities = new DesiredCapabilities("", "", Platform.ANY);
		//capabilities.setCapability("securityToken", securityToken);
		//capabilities.setCapability("deviceName", "RF8M8208LHL");
		//capabilities.setCapability("deviceName", "00008020-000629400C50003A");
		
		//Capabilities with IOS device attributes
		DesiredCapabilities capabilities = new DesiredCapabilities("", "", Platform.ANY);
		capabilities.setCapability("securityToken", securityToken);
		capabilities.setCapability("platformName", "iOS");
		capabilities.setCapability("platformVersion", "12.0");
		capabilities.setCapability("location", "NA-US-BOS");
		capabilities.setCapability("resolution", "1125x2436");
		capabilities.setCapability("manufacturer", "Apple");
		capabilities.setCapability("model", "iPhone-XS");
		
		try{
			System.out.println("Cloud URL - " + "https://" + cloudName + ".perfectomobile.com/nexperience/perfectomobile/wd/hub");
			driver = new RemoteWebDriver(new URL("https://" + Utils.fetchCloudName(cloudName) + ".perfectomobile.com/nexperience/perfectomobile/wd/hub"), capabilities);
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
		}catch(SessionNotCreatedException e){
			throw new RuntimeException("Driver not created with capabilities: " + capabilities.toString());
		}

		reportiumClient = Utils.setReportiumClient(driver, reportiumClient); //Creates reportiumClient
		reportiumClient.testStart("Perfecto mobile IOS test", new TestContext("tag2", "tag3")); //Starts the reportium test
		reportiumClient.stepStart("Open Run app in Perfecto IOS device"); 
		//Open RUN app in IOS device
		Map<String, Object> params = new HashMap<>();
		params.put("identifier", "com.adp.runmobile"); 
		driver.executeScript("mobile:application:open", params);
		System.out.println("Run app from IOS Device - Started");
		
		// Enter User name and Password and click Signin
		//driver.findElement(By.name("User ID Input")).sendKeys("owner@21981753");
		//driver.findElement(By.xpath("//*[@label=\"User ID Input\"]")).sendKeys("owner@21981753");
		
		Thread.sleep(20000);
		
		// Login - Enter User name and Password and click Signin
		driver.findElement(By.name("User ID Input")).sendKeys("owner@21981753");
		driver.findElement(By.name("Password Input")).sendKeys("test1357");
		driver.findElement(By.name("Sign In")).click();
		
		
		// Login - With Xpaths
		//driver.findElement(By.xpath("//[@label='User ID Input']")).sendKeys("owner@21981753");
		//driver.findElement(By.xpath("//[@label='Password Input']")).sendKeys("test1357");
		//driver.findElement(By.xpath("//[@label='Sign In']")).click();

		// Login - With Actions 
		//Actions action = new Actions(driver);
		//action.sendKeys("owner@21981753").build().perform();
		//action.sendKeys(Keys.TAB).build().perform();
		//action.sendKeys("test1357").build().perform();
		//action.sendKeys(Keys.TAB).build().perform();
		//action.sendKeys(Keys.ENTER).build().perform();

		// Login - With Absolute Xpaths of Native Objects
		//WebDriverWait wait = new WebDriverWait(driver, 30);
		//wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//AppiumAUT/XCUIElementTypeApplication[1]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeTextField[1]"))));
		//driver.findElement(By.xpath("//AppiumAUT/XCUIElementTypeApplication[1]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeOther[1]/XCUIElementTypeTextField[1]")).sendKeys("owner@21981753");
		//driver.findElement(By.xpath("//XCUIElementTypeTextField[@name='User ID Input']")).sendKeys("owner@21981753");
		//driver.findElement(By.name("User ID Input")).sendKeys("owner@21981753"); // User ID Input
		//driver.findElement(By.xpath("//XCUIElementTypeSecureTextField[@name='Password Input']")).sendKeys("test1357");
		//driver.findElement(By.name("Password Input")).sendKeys("test1357"); // Password Input
		//driver.findElement(By.xpath("//XCUIElementTypeButton[@name='Sign In']")).click();
		//driver.findElement(By.name("Sign In")).click(); // Sign In

		reportiumClient.stepEnd();
		reportiumClient.stepStart("Close the RUN App in IOS device");
		
		//Close the RUN app
		Map<String, Object> params1 = new HashMap<>();
		params1.put("identifier", "com.adp.runmobile");
		driver.executeScript("mobile:application:close", params);
		System.out.println("RUN App Closed");
		reportiumClient.stepEnd();
	}

	@AfterMethod
	public void afterMethod(ITestResult result) {
		//STOP TEST
		TestResult testResult = null;

		if(result.getStatus() == result.SUCCESS) {
			testResult = TestResultFactory.createSuccess();
		}
		else if (result.getStatus() == result.FAILURE) {
			testResult = TestResultFactory.createFailure(result.getThrowable());
		}
		reportiumClient.testStop(testResult);

		driver.close();
		driver.quit();
		System.out.println();
		// Retrieve the URL to the DigitalZoom Report 
		String reportURL = reportiumClient.getReportUrl();
		System.out.println(reportURL);
	}
}

